import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matrice',
  templateUrl: './matrice.component.html',
  styleUrls: ['./matrice.component.css']
})
export class MatriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
